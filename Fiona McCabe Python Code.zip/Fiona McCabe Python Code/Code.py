import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import seaborn as sns

def importdata(filename):
    try:
        data=pd.read_csv(filename, encoding='cp1252')
        print(data.head())
        print(data.shape)
    except:
        print("Cannot find file " + filename)
        data = 0
    return data

#Importing crops csv and subsetting data to only show crops produced in France
crops=importdata("Crops_AllData_Normalized.csv")
france_crop= (crops[crops["Area"]== "France"])
france_crop_prod = (france_crop[france_crop["Element"] == "Production"])

#Droping columns that I do not require
france_drop=france_crop_prod.drop(columns = ["Area Code", "Item Code", "Element Code", "Year Code"])

#sorting by value column to show the largest crops first
france_crop_prod_sorted= france_drop.sort_values("Value", ascending=False)
print("French crops produced by year, sorted by value")
print(france_crop_prod_sorted)

#replacing missing values wih 0
france_crop_fill = (france_crop_prod_sorted.fillna(0))
print("French crops produced by year, sorted by value with NaN's replaced by 0")
print(france_crop_fill)

#Grouping by type of crop produced, getting the total of each crop and sorting in descending order
france_data=france_crop_fill.groupby(["Item"]).sum().sort_values("Value", ascending=False)
df_france = france_data.reset_index()
print("Total crop output grouped by item")
print(df_france)

#Plotting the top 15 crops produced in France on a bar graph
france_data_top16=df_france[:16].plot(x="Item", y="Value", kind ="bar", rot=90, color="green", legend=None)
plt.xlabel("Type of Crop Produced")
plt.ylabel("Total volume of crop produced in 'billion tonnes")
plt.title("Top 15 Crops produced in France from 1961-2019")
plt.plot()

#Selecting the top crop produced in France, Cereals and setting the index to the column Years to enable the data to be plotted
cereals_only_france=(france_drop[france_drop["Item"] == "Cereals, Total"]).set_index("Year")
print("Cereals, Total for France only with the year set as index")
print(cereals_only_france)

#Plotting total cereals for all years in France on a line plot
fig, ax = plt.subplots()
graph=ax.plot(cereals_only_france.index, cereals_only_france["Value"])
graph=ax.set_xlabel("Time")
graph=ax.set_ylabel("Volume in 'billion tonnes")
graph=ax.set_title("Total volume of cereals produced in France 1961-2019")
plt.plot()

#For total cereals produced in 2019, comparing where France ranks verses all other countries
global_cereals = crops.loc[(crops.Element == 'Production') & (crops.Year == 2019) & (crops.Item == "Cereals, Total")]

#using numpy unique to select all countries once from the data
countries = crops.Area.unique()
area = []
amnt = []
for country in countries:
    #Adding in error handling to deal with characters that cannot be understood
    try:
        temp = global_cereals.loc[global_cereals.Area == country]
    except:
        print("country=" + country)
    amount = temp.Value.sum()
    area.append(country)
    amnt.append(amount)

#Creating a dictionary
data_global_cereals = pd.DataFrame({'Country': area, 'Amount': amnt})

#sorting values by largest first
data_global_cereals = data_global_cereals.sort_values('Amount', ascending=False)

#Subsetting the data to be show
data_global_cereals=data_global_cereals[1:42]

#Plotting & labelling the data on a bar chart
g = sns.catplot(x="Country", y="Amount", data=data_global_cereals, kind="bar")
g.set_xticklabels(rotation=90)
g.set_axis_labels("Country", "Volume in billion tonnes")
g.fig.suptitle("Total cereals produced by country / region in 2019")
plt.plot()

#Importing the total population csv
population = importdata("Total_Population_All_Countries.csv")

#dropping all columns not required
pop_drop = population.drop=(["LocID", "VarID", "PopMale", "PopFemale", "PopDensity"])

#subsetting the data to only include France and where the variant is medium
france_pop = (population[population["Location"] == "France"])
france_pop_medium = france_pop.loc[france_pop.Variant == 'Medium']

#selecting only the years which are greater than or equal to 1960 and less than or equal to 2019
france_pop_filtered = france_pop_medium.loc[(france_pop_medium.Time >= 1961) & (france_pop_medium.Time <= 2019)]
print("Medium France population 1961-2019")
print(france_pop_filtered)

#graphing medium France population on a line graph
france_pop_filtered.plot(x="Time", y="PopTotal", kind="line", linewidth=2.0)
plt.xlabel("Years")
plt.ylabel("Population '000")
plt.title("Medium population in France 1961-2019")
plt.plot()

#merging of population and total cereals produced dataframes
#renaming the column heading in the population dataframe so that merge can be made on this column
france_pop_filtered_renamed = france_pop_filtered.rename(columns={"Time": "Year"})

#setting the index in the population dataframe to Year
france_pop_index_set = france_pop_filtered_renamed.set_index("Year")

#merging of the dataframes
cereals_pop = cereals_only_france.merge(france_pop_index_set, on="Year", how="left")
print("Cereals and population dataframes merged")
print(cereals_pop)

#graphing the merged dataframe using two x-axis
fig, ax = plt.subplots()
ax.plot(cereals_pop.index, cereals_pop["Value"], label="Total cereals produced", color="R")
ax.set_xlabel("Time")
ax.set_ylabel("Total Cereal Production Spain 'Million Tonnes")
ax2 = ax.twinx()
ax2.plot(cereals_pop.index, cereals_pop["PopTotal"], label="Total population", linestyle="--")
ax2.set_ylabel("Population Total '000")
ax.set_title("Correlation between population and cereal crops produced")
fig.legend()
plt.plot()

#Calculating the coefficent of my data
correlation = np.corrcoef(cereals_pop["Value"], cereals_pop["PopTotal"])
print(correlation)

plt.show()